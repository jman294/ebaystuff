document.querySelectorAll('.th-title-text')[3].addEventListener('click', function () {if (window.location.href.includes('-')){window.location.href = "/sh/lst/active?sort=visitCount&action=sort";} else {window.location.href = "/sh/lst/active?sort=-visitCount&action=sort";}})
console.log('asdf')
